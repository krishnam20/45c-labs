//
//  convert.cpp
//  lab1
//
//  Created by Huyanh Hoang on 2016. 7. 5..
//  Copyright © 2016년 Huyanh Hoang. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, char *argv[] ) {
    int knots;
    double milesPerMinute;
    
    cout << "Enter amount in knots: ";
    cin >> knots;
    
    milesPerMinute = static_cast<double>(knots) * 6076 / (5280 * 60);
    cout << "This is " << milesPerMinute << " miles per minute" << endl;
    
    return 0;
}