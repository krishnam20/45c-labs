//
//  main.cpp
//  lab1
//
//  Created by Huyanh Hoang on 2016. 6. 30..
//  Copyright © 2016년 Huyanh Hoang. All rights reserved.
//

//
//  lab1.cpp
//  lab1
//
//  Created by Huyanh Hoang on 2016. 6. 30..
//
//

#include <iostream>
using namespace std;

int main( int argc, char *argv[] )
{
    cout << "Hello World!" << endl;
    return 0;
}